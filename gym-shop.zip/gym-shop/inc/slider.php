<div class="header_bottom">
		
		</div>
			 <div class="header_bottom_right_images">
		   <!-- FlexSlider -->
             
			<section class="slider">
				  <div class="flexslider">
					<ul class="slides">
						<li><img src="images/1a.png" alt=""/></li>
						<li><img src="images/jt.png" alt=""/></li>
						<li><img src="images/jta.png" alt=""/></li>
						<li><img src="images/jtb.png" alt=""/></li>
				    </ul>
				  </div>
	      </section>
<!-- FlexSlider -->
	    </div>
	  <div class="clear"></div>
  </div>
